import AppRoutes from "./AppRoutes";

export default function App() {
  return <AppRoutes />;
}
