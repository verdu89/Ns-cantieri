
const NewJob = () => {
  return (
    <div className="bg-white shadow rounded-xl p-6 border max-w-2xl">
      <h1 className="text-xl font-bold mb-4">Nuovo Lavoro</h1>
      <p className="text-sm text-gray-600">Form mock…</p>
    </div>
  );
};

export default NewJob;
