export const settingsAPI = {
  async ping(): Promise<"ok"> {
    return "ok";
  },
};
